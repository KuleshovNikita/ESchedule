export const availableRules = {
    teacherBusyDayRule: 'rules.teacher-busy-day'
}