export const loadingSpinnerStyle = { 
    display: 'flex', 
    justifyContent: 'center', 
    alignItems: 'center',
    mt: 3
}