export default interface BaseEntity {
    id: string;
}